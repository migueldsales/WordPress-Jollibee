<?php
/*
 * No direct access to this file
 */
if (! isset($data, $criticalCssConfig)) {
	exit;
}

$locationKey = 'date';

require_once __DIR__.'/common/_settings.php';
