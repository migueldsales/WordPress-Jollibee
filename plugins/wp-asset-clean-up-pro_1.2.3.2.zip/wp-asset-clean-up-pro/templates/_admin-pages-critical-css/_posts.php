<?php
/*
 * No direct access to this file
 */
if (! isset($data, $criticalCssConfig)) {
	exit;
}

$locationKey = 'posts';

require_once __DIR__.'/common/_settings.php';
